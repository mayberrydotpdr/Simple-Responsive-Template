

var siteWide_Menu_on_or_off = "on";






var siteWide_MenuList = [



"Introduction.html",

"Simple_Responsive_Template_Tutorial.html",

"Sample_Google_Docs.html",

"140_color_names.html",

"99_Bottles_of_Beer_on_the_Wall.html"


];
/*

Examples of additional features:


(embed-video-or-html-code) <div class="video-container"><iframe width="562" height="316" src="https://www.youtube.com/embed/F1anRyL37lE" frameborder="0" gesture="media" allowfullscreen></iframe></div> (embed-video-or-html-code)

(embed-video-asset)   HTML5Video.mp4   (embed-video-asset)

(embed-audio-asset)   Hal.mp3   (embed-audio-asset)

(linked-image-asset)    logo.png    link-to-address:    https://www.bing.com    (linked-image-asset)

*/